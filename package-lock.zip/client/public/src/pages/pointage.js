import { post, get } from '../api.js';
import { savePointage } from '../store/indexedDB.js';
import { showModal } from '../components/modal.js';
import { showToast } from '../components/toast.js';

// Scanner state management
let animationId = null;
let isProcessing = false;

function playBeep() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.frequency.value = 880;
    osc.type = 'square';
    gain.gain.setValueAtTime(0.2, ctx.currentTime);
    osc.start();
    osc.stop(ctx.currentTime + 0.15);
  } catch (e) {
    // ignore
  }
}

async function enregistrerPointage(agent, methode, type = 'arrivee') {
  const now = new Date();
  const payload = {
    local_id: crypto.randomUUID(),
    agent_id: agent._id || agent.id,
    site_id: agent.site_id?._id || agent.site_id,
    date: now.toISOString().split('T')[0],
    methode,
    type
  };

  try {
    if (navigator.onLine) {
      await post('/api/pointages', payload);
      const action = type === 'depart' ? 'Départ' : 'Arrivée';
      showToast(
        `✅ ${agent.prenom || ''} ${agent.nom || ''} — ${action} enregistrée`,
        'success'
      );
    } else {
      await savePointage({
        ...payload,
        sync_status: 'local'
      });
      showToast(
        `📶 ${agent.prenom || ''} ${agent.nom || ''} — Pointage sauvegardé hors ligne`,
        'success'
      );
    }
    playBeep();
    return true;
  } catch (err) {
    showToast(
      "Erreur lors de l'enregistrement du pointage. Il sera réessayé plus tard.",
      'error'
    );
    return false;
  }
}

async function rechercherAgentParNumeroEmploye(numero_employe) {
  const response = await fetch(
    `/api/agents/search?numero_employe=${encodeURIComponent(numero_employe)}`,
    {
      headers: {
        Authorization: `Bearer ${localStorage.getItem('gds_token') || ''}`
      }
    }
  );
  if (!response.ok) {
    throw new Error('Agent introuvable');
  }
  const data = await response.json();
  return data;
}

function stopScanner() {
  if (animationId) {
    cancelAnimationFrame(animationId);
    animationId = null;
  }
}

function resumeScanner(scanFunction) {
  isProcessing = false;
  animationId = requestAnimationFrame(scanFunction);
}

async function reloadPointagesList(container) {
  try {
    const user = JSON.parse(localStorage.getItem('gds_user'));
    if (!user || !user.site_id) {
      container.innerHTML = '<div style="color:#999; text-align:center; padding:20px 10px;">Impossible de charger les pointages.</div>';
      return;
    }

    const today = new Date();
    const dateStr = today.toISOString().split('T')[0];

    const response = await get(`/api/pointages?site_id=${user.site_id}&date=${dateStr}`);
    const pointages = response && response.data ? response.data : [];

    if (!Array.isArray(pointages) || pointages.length === 0) {
      container.innerHTML = '<div style="color:#999; text-align:center; padding:20px 10px;">Aucun pointage pour aujourd\'hui.</div>';
      return;
    }

    // Trier par heure d'arrivée
    pointages.sort((a, b) => {
      const timeA = a.heure_arrivee || '00:00';
      const timeB = b.heure_arrivee || '00:00';
      return timeA.localeCompare(timeB);
    });

    let html = '<div style="display:flex; font-weight:600; padding:8px; background:#f5f5f5; border-radius:8px; margin-bottom:8px;"><div style="flex:2;">Nom</div><div style="flex:1;">Arrivée</div><div style="flex:1;">Départ</div><div style="flex:1;">Durée</div><div style="flex:1;">Statut</div></div>';
    pointages.forEach(p => {
      const agent = p.agent_id || {};
      const arrivee = p.heure_arrivee || '—';
      const depart = p.heure_depart || '—';
      const statut = p.statut || '—';
      let duree = '—';
      if (p.heure_arrivee && p.heure_depart) {
        const [h1, m1] = p.heure_arrivee.split(':').map(Number);
        const [h2, m2] = p.heure_depart.split(':').map(Number);
        const diff = (h2 * 60 + m2) - (h1 * 60 + m1);
        if (diff > 0) {
          const hours = Math.floor(diff / 60);
          const mins = diff % 60;
          duree = `${hours}h${mins.toString().padStart(2, '0')}`;
        }
      }
      const methode = p.methode === 'qr_code' ? '📱' : '✋';

      html += `
        <div class="pointage-card" style="display:flex; align-items:center; padding:12px; border:1px solid #eee; border-radius:8px;">
          <div style="flex:2; font-weight:600;">${agent.prenom || ''} ${agent.nom || ''} ${methode}</div>
          <div style="flex:1;">${arrivee}</div>
          <div style="flex:1;">${depart}</div>
          <div style="flex:1;">${duree}</div>
          <div style="flex:1;">${statut}</div>
        </div>
      `;
    });
    container.innerHTML = html;
  } catch (err) {
    console.error('Erreur lors du chargement des pointages:', err);
    container.innerHTML = '<div style="color:#c62828; text-align:center; padding:20px 10px;">Erreur lors du chargement.</div>';
  }
}

function startCamera(video, canvas, onCodeDetected) {
  const ctx = canvas.getContext('2d', { willReadFrequently: true });

  navigator.mediaDevices
    .getUserMedia({ video: { facingMode: 'environment' } })
    .then((stream) => {
      video.srcObject = stream;
      video.setAttribute('playsinline', 'true');
      video.play();

      function scanFrame() {
        // Ignore if already processing a detection
        if (isProcessing) {
          animationId = requestAnimationFrame(scanFrame);
          return;
        }

        if (video.readyState === video.HAVE_ENOUGH_DATA) {
          canvas.height = video.videoHeight;
          canvas.width = video.videoWidth;
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
          const imageData = ctx.getImageData(
            0,
            0,
            canvas.width,
            canvas.height
          );
          const jsqrFn =
            (typeof window !== 'undefined' && window.jsQR) ||
            (typeof jsQR === 'function' ? jsQR : null);
          if (!jsqrFn) {
            showToast(
              "Le module de lecture QR (jsQR) n'est pas disponible.",
              'error'
            );
            return;
          }
          const code = jsqrFn(imageData.data, imageData.width, imageData.height, {
            inversionAttempts: 'dontInvert'
          });
          if (code && code.data) {
            isProcessing = true;
            stopScanner();
            onCodeDetected(code.data, () => resumeScanner(scanFrame));
          }
        }
        animationId = requestAnimationFrame(scanFrame);
      }

      animationId = requestAnimationFrame(scanFrame);
    })
    .catch(() => {
      showToast(
        'Impossible d’accéder à la caméra. Vérifiez les autorisations.',
        'error'
      );
    });
}

export function renderPointage(root) {
  root.innerHTML = `
    <div style="display:flex; flex-direction:column; gap:16px;">
      <!-- Pointage Manuel Section -->
      <div class="card">
        <h2 style="font-size:1rem; font-weight:600; margin-bottom:12px;">Pointage Manuel</h2>
        
        <!-- Horloge -->
        <div style="text-align:center; margin-bottom:16px;">
          <div id="current-time" style="font-size:2rem; font-weight:700; color:#2E7D32;"></div>
          <div id="current-date" style="font-size:0.9rem; color:#666;"></div>
        </div>
        
        <!-- Recherche -->
        <div style="display:flex; gap:8px; margin-bottom:8px;">
          <input id="input-search" placeholder="Rechercher par nom ou numéro employé" style="flex:1;" />
          <button id="btn-search-agent" class="btn-primary" style="flex:0 0 auto; padding:10px 14px;">Chercher</button>
        </div>
        
        <!-- Liste déroulante agents -->
        <select id="select-agent" style="width:100%; padding:10px; margin-bottom:8px; border:1px solid #ddd; border-radius:8px; display:none;">
          <option value="">Sélectionner un agent</option>
        </select>
        
        <!-- Boutons Arrivée/Départ -->
        <div id="action-buttons" style="display:flex; gap:8px; display:none;">
          <button id="btn-arrivee" class="btn-large" style="flex:1; background:#4CAF50;">Arrivée</button>
          <button id="btn-depart" class="btn-large" style="flex:1; background:#2196F3;">Départ</button>
        </div>
        
        <div id="manuel-result" style="font-size:0.85rem; color:#666;"></div>
      </div>

      <!-- Scan QR Section (accordéon) -->
      <div class="card">
        <details>
          <summary style="cursor:pointer; font-weight:600; margin-bottom:12px;">Scan QR</summary>
          <div style="display:flex; flex-direction:column;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
              <button id="btn-start-camera" class="btn-large" style="width:auto; padding:8px 16px;">Caméra</button>
            </div>
            <div id="camera-area" style="width:100%; aspect-ratio:1; max-height:60vw; background:#000; border-radius:10px; position:relative; overflow:hidden; display:flex; align-items:center; justify-content:center;">
              <video id="video" style="width:100%; height:100%; transform:scaleX(-1); object-fit:cover;"></video>
              <canvas id="canvas" style="display:none;"></canvas>
              <div style="position:absolute; border:3px solid #4CAF50; width:60%; height:60%; border-radius:8px;"></div>
            </div>
          </div>
        </details>
      </div>

      <!-- Pointages du jour Section -->
      <div class="card">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
          <h2 style="font-size:1rem; font-weight:600;">Pointages du jour</h2>
          <span id="badge-pending" class="badge-pending">0 en attente</span>
        </div>
        <div id="liste-pointages" style="display:flex; flex-direction:column; gap:8px;">
          <div style="color:#999; text-align:center; padding:20px 10px;">Les pointages apparaîtront ici.</div>
        </div>
      </div>
    </div>
  `;

  // Horloge en temps réel
  function updateClock() {
    const now = new Date();
    const timeStr = now.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const dateStr = now.toLocaleDateString('fr-FR', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
    const timeEl = root.querySelector('#current-time');
    const dateEl = root.querySelector('#current-date');
    if (timeEl) timeEl.textContent = timeStr;
    if (dateEl) dateEl.textContent = dateStr;
  }
  updateClock();
  setInterval(updateClock, 1000);

  const btnSearchAgent = root.querySelector('#btn-search-agent');
  const inputSearch = root.querySelector('#input-search');
  const selectAgent = root.querySelector('#select-agent');
  const actionButtons = root.querySelector('#action-buttons');
  const btnArrivee = root.querySelector('#btn-arrivee');
  const btnDepart = root.querySelector('#btn-depart');
  const manuelResult = root.querySelector('#manuel-result');
  const btnCamera = root.querySelector('#btn-start-camera');
  const video = root.querySelector('#video');
  const canvas = root.querySelector('#canvas');
  const listePointages = root.querySelector('#liste-pointages');

  // Recherche agents
  btnSearchAgent.addEventListener('click', async () => {
    const query = inputSearch.value.trim();
    if (!query) {
      manuelResult.textContent = 'Veuillez entrer un nom ou numéro employé.';
      return;
    }
    try {
      const response = await get(`/api/agents?search=${encodeURIComponent(query)}&limit=10`);
      const agents = response && response.data ? response.data : [];
      if (agents.length === 0) {
        manuelResult.textContent = 'Aucun agent trouvé.';
        selectAgent.style.display = 'none';
        actionButtons.style.display = 'none';
        return;
      }
      selectAgent.innerHTML = '<option value="">Sélectionner un agent</option>';
      agents.forEach(agent => {
        const option = document.createElement('option');
        option.value = agent._id;
        option.textContent = `${agent.prenom} ${agent.nom} (${agent.numero_employe})`;
        option.dataset.agent = JSON.stringify(agent);
        selectAgent.appendChild(option);
      });
      selectAgent.style.display = 'block';
      actionButtons.style.display = 'none';
      manuelResult.textContent = `${agents.length} agent(s) trouvé(s).`;
    } catch (err) {
      manuelResult.textContent = "Erreur lors de la recherche.";
    }
  });

  // Sélection agent
  selectAgent.addEventListener('change', () => {
    if (selectAgent.value) {
      actionButtons.style.display = 'flex';
    } else {
      actionButtons.style.display = 'none';
    }
  });

  // Bouton Arrivée
  btnArrivee.addEventListener('click', async () => {
    const selectedOption = selectAgent.options[selectAgent.selectedIndex];
    const agent = JSON.parse(selectedOption.dataset.agent);
    await enregistrerPointage(agent, 'manuel', 'arrivee');
    await reloadPointagesList(listePointages);
  });

  // Bouton Départ
  btnDepart.addEventListener('click', async () => {
    const selectedOption = selectAgent.options[selectAgent.selectedIndex];
    const agent = JSON.parse(selectedOption.dataset.agent);
    await enregistrerPointage(agent, 'manuel', 'depart');
    await reloadPointagesList(listePointages);
  });

  // Load initial pointages for today
  if (listePointages) {
    reloadPointagesList(listePointages);
  }

  btnCamera.addEventListener('click', () => {
    startCamera(video, canvas, async (numero_employe, resumeCallback) => {
      showToast(`QR détecté : ${numero_employe}`, 'info');
      try {
        const agent = await rechercherAgentParNumeroEmploye(numero_employe);
        if (!agent) {
          showToast('Agent introuvable pour ce QR.', 'error');
          resumeCallback();
          return;
        }
        const content = `
          <div style="display:flex; gap:10px; align-items:center;">
            <div style="width:60px; height:60px; border-radius:50%; overflow:hidden; background:#eee;">
              ${
                agent.photo
                  ? `<img src="${agent.photo}" style="width:100%; height:100%; object-fit:cover;" />`
                  : ''
              }
            </div>
            <div>
              <div style="font-weight:600;">${agent.prenom || ''} ${agent.nom || ''}</div>
              <div style="font-size:13px; color:#546e7a;">Numéro employé ${
                agent.numero_employe
              }</div>
              <div style="font-size:13px; color:#78909c;">${
                agent.type_contrat || ''
              }</div>
            </div>
          </div>
        `;
        showModal({
          title: 'Confirmer présence',
          content,
          confirmText: 'Confirmer présence',
          cancelText: 'Annuler',
          onConfirm: async (close) => {
            const success = await enregistrerPointage(agent, 'qr_code');
            if (success) {
              await reloadPointagesList(listePointages);
            }
            resumeCallback();
            close();
          },
          onCancel: resumeCallback
        });
      } catch (err) {
        showToast(
          "Erreur lors de la récupération de l'agent pour ce QR.",
          'error'
        );
        resumeCallback();
      }
    });
  });
}

